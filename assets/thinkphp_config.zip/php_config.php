<?php

include_once 'function.php';
$source_com_config_file_path  = "src/common_config.php";
$source_cron_config_file_path = "src/crontab_config.php";
$source_cron_index_file_path  = "src/crontab_demo.php";
$dist_com_config_Path         = "dist/"; // common下的文件操作
$dist_cron_file_Path          = "dist/Crontab/"; // crontab目标目录

$version       = '0.1';
$version_array = array('-v', 'v', '-V', 'V', 'version', '-version', '--v', '--V', '--version');
$config        = array(
    'crontab_log_dir' => "CRONTAB_LOG_DIR", // 此项配置请勿修改
    "db_name"         => 'DB_NAME',// session和data cache的前缀,token 公用，prefix前缀
    'appid'           => 'AppID',
    'appsecret'       => 'AppSecret',
    'app_url'         => 'app_url',
);

// console only
$sapi = php_sapi_name();
if ($sapi == 'cli') {
    $helper = new Helper();
    if (count($argv) > 1 && in_array($argv[1], $version_array)) {
        $usage = $helper->usage();
        print($usage);
        exit();
    }
    
    $handler = fopen('php://stdin', 'r');
    $temp    = array();
    foreach ($config as $key => $value) {
        $t = '';
        do {
            echo "Please input " . $value . " => ";
            fscanf($handler, "%s", $t);
        } while (!$t);
        $temp[ $value ] = $t;
    }
    try {
        print("================== output =========================\n");
        
        // build crontab config file
        $cron_conf_status = $helper->add_crontab_config($source_cron_config_file_path, $dist_cron_file_Path, $temp['DB_NAME'], $temp['CRONTAB_LOG_DIR']);
        if ($cron_conf_status == FALSE) {
            exit("create crontab config file failed!!\n" . __FILE__ . " " . __LINE__);
        } else {
            print("crontab config create success!!\n");
        }
        unset($temp['CRONTAB_LOG_DIR']);
        
        // build crontab index file
        $cron_index_status = $helper->add_crontab_index($source_cron_index_file_path, $dist_cron_file_Path, $temp['DB_NAME']);
        if ($cron_index_status == FALSE) {
            exit("create crontab index file failed!!\n" . __FILE__ . " " . __LINE__);
        } else {
            print("crontab config create success!!\n");
        }
        
        // build common config file
        $common_config_status = $helper->add_common_config($source_com_config_file_path, $dist_com_config_Path, $temp);
        if ($cron_index_status == FALSE) {
            exit("common config index file failed!!\n" . __FILE__ . " " . __LINE__);
        } else {
            print("common config create success!!\n");
        }
        print("================== end =========================");
    } catch (Exception $e) {
        $helper->clear($e->getCode());
        print($e->getMessage());
    };
} else {
    exit("Fatal error! This script run only cli");
}

