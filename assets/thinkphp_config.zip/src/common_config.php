<?php
return array(
    'DB_TYPE' => 'mysqli',
    'DB_HOST' => 'rm-2ze11bm754mqfdm95.mysql.rds.aliyuncs.com',
    'DB_NAME' => 'gounian', //1
    'DB_USER' => 'xiaoyu_pro',
    'DB_PWD' => 'f39676201ce477cac5ec794c619ab164',
    'DB_PORT' => 3306,
    'DB_PREFIX' => 'ac_',
    'DEFAULT_MODULE' => 'Gounian',
    'MODULE_ALLOW_LIST' => array(
        'Gounian'
    ),
    'URL_CASE_INSENSITIVE' => true,
    'URL_MODEL' => 2,
    'SESSION_TYPE' => 'Memcache',
    'MEMCACHE_HOST' => 'm-2zeff2f7b1263f14.memcache.rds.aliyuncs.com',
    'MEMCACHE_PORT' => '11211',
    'SESSION_OPTIONS' => array(
        'name' => 'gounian1',
        'expire' => 180000
    ),
    'SESSION_PREFIX' => 'gounian1', //2
    'DATA_CACHE_TYPE' => 'Memcache',
    'DATA_CACHE_PREFIX' => 'gounian1',
    'AppID'=>'wx47845c3b9a40cd84', //5
    'AppSecret'=>'1858637ff60226e215544cf337986961', //6
    'Token'=>'gounian1', //7
    'AppName'=>'狗年测试',
    "app_url"=>'', //8
);