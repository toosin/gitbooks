<?php

class Helper {
    // 管理整个创建的文件
    private $creat_file_list = array();
    
    protected function add_create_file_list($filename) {
        $this->creat_file_list[] = $filename;
    }
    
    private function put_config_file($file_name,$data){
        $str = "<?php\nreturn " . var_export($data, TRUE) . ";\n";
        file_put_contents($file_name, $str);
    }
    
    private function handler_dist($dist){
        $length = strlen($dist);
        $last = $dist[$length - 1];
        if($last != '/'){
            $dist = $dist."/";
        }
        return $dist;
    }
    
    public function usage() {
        
        $usage = <<<EOF
Hello! welcome usage the thinkphp 3.2 configs build script,this script can build common config && crontab config && crontab index
version:    0.1
author:     xiaoyu-tech
time:       2018-03-05 16:41:31
usage:      php php_config.php
EOF;
        
        return $usage;
    }
    
    /**
     * 添加crontab的配置文件
     *
     * @param string $src       crontab配置文件的源文件路径
     * @param string $dist      crontab配置文件的目标文件的存放目录
     * @param string $dir       crontab日志文件的存放木
     * @param string $file_name crontab配置文件的文件名
     *
     * @return bool
     * @throws \Exception
     */
    public function add_crontab_config($src, $dist, $file_name, $crontab_log_dir) {
        if (!is_file($src)) {
            throw new Exception('crontab config source file is not exist', 1);
        }
        
        if (!is_dir($dist)) {
            throw new Exception('crontab config dist is not dir', 1);
        }
        $dist = $this->handler_dist($dist);
        
        $crontab_config                    = require_once($src);
        $crontab_config['CRONTAB_LOG_DIR'] = $crontab_log_dir;
        $fn                                = $dist . "Conf/" . $file_name . ".php";
        $this->put_config_file($fn,$crontab_config);
        if (is_file($fn)) {
            $this->add_create_file_list($fn);
            
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    /**
     * @param        $src
     * @param        $dist
     * @param        $str
     * @param string $replace_default
     *
     * @throws \Exception
     */
    public function add_crontab_index($src, $dist, $file_name, $replace_default = 'xxx') {
        if (!is_file($src)) {
            throw new Exception('crontab index file is not exist', 2);
        }
        if (!is_dir($dist)) {
            throw new Exception('crontab index dist is not dir', 2);
        }
        $dist = $this->handler_dist($dist);
        
        $crontab_index       = file_get_contents($src);
        $crontab_index_build = str_replace($replace_default, $file_name, $crontab_index);
        $fn                  = $dist . $file_name . ".php";
        file_put_contents($fn, $crontab_index_build);
        
        if (is_file($fn)) {
            $this->add_create_file_list($fn);
            
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    /**
     * @param $src
     * @param $dist
     * @param $replace_array
     *
     * @throws \Exception
     */
    public function add_common_config($src, $dist, $replace_array) {
        // replace database name and some prefix
        if (!is_file($src)) {
            throw new Exception('common config file is not exist', 3);
        }
        
        if (!is_dir($dist)) {
            throw new Exception('common config dir is not exist', 3);
        }
        $dist = $this->handler_dist($dist);
        
        $config = require_once($src);
        $prefix = $replace_array['DB_NAME'];
        if (array_key_exists('name', $config['SESSION_OPTIONS'])) {
            $config['SESSION_OPTIONS']['name'] = $prefix;
        }
        if (array_key_exists('SESSION_PREFIX', $config)) {
            $config['SESSION_PREFIX'] = $prefix;
        }
        
        if (array_key_exists('DATA_CACHE_PREFIX', $config)) {
            $config['DATA_CACHE_PREFIX'] = $prefix;
        }
        
        if (array_key_exists('Token', $config)) {
            $config['Token'] = $prefix;
        }
        
        foreach ($replace_array as $key => $value) {
            $config[ $key ] = $value;
        }
        
        $fn = $dist.''.$prefix.".php";
        $this->put_config_file($fn,$config);
        if(is_file($fn)){
            $this->add_create_file_list($fn);
            return TRUE;
        }else{
            return FALSE;
        }
    }
    
    /**
     * code 的取值问题，1代表add_crontab_config文件还未创建,
     *
     * @param $code
     */
    public function clear($code) {
        if ($code == 1) {
            // do nothing
        } elseif ($code == 2) {
            unlink($this->creat_file_list[0]);
        } elseif ($code == 3) {
            unlink($this->creat_file_list[0]);
            unlink($this->creat_file_list[1]);
        }else{
            foreach ($this->creat_file_list as $key=>$value){
                unlink($this->creat_file_list[$key]);
            }
        }
    }
}